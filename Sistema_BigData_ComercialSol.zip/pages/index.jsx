import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";

const initialData = {
  vendas: 15000,
  estoque: [
    { produto: "Arroz", quantidade: 15 },
    { produto: "Feijão", quantidade: 5 },
    { produto: "Óleo", quantidade: 8 },
  ],
  caixa: {
    entradas: 18000,
    saidas: 12000,
  },
};

export default function SistemaInterno() {
  const [usuario, setUsuario] = useState("");
  const [senha, setSenha] = useState("");
  const [logado, setLogado] = useState(false);
  const [dados, setDados] = useState(initialData);

  const estoqueBaixo = dados.estoque.filter((item) => item.quantidade < 10);
  const saldoCaixa = dados.caixa.entradas - dados.caixa.saidas;

  if (!logado) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-100">
        <div className="bg-white p-8 rounded-xl shadow-md w-full max-w-sm">
          <h1 className="text-2xl font-bold text-center mb-6">Acesso ao Sistema Interno</h1>
          <div className="space-y-4">
            <Input
              placeholder="Usuário"
              value={usuario}
              onChange={(e) => setUsuario(e.target.value)}
            />
            <Input
              type="password"
              placeholder="Senha"
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
            />
            <Button
              className="w-full"
              onClick={() => {
                if (usuario === "admin" && senha === "1234") {
                  setLogado(true);
                } else {
                  alert("Usuário ou senha inválidos");
                }
              }}
            >
              Entrar
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="grid gap-4 p-4">
      <h1 className="text-xl font-bold">Painel de Informações Internas</h1>

      <Card>
        <CardContent className="p-4">
          <h2 className="font-semibold">Resumo de Vendas</h2>
          <p>Total de vendas do mês: R$ {dados.vendas.toFixed(2)}</p>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <h2 className="font-semibold">Estoque</h2>
          <ul>
            {dados.estoque.map((item, idx) => (
              <li key={idx}>
                {item.produto}: {item.quantidade} unidades
              </li>
            ))}
          </ul>
          {estoqueBaixo.length > 0 && (
            <div className="mt-2 text-red-600">
              <strong>Alerta de Estoque Baixo:</strong>
              <ul>
                {estoqueBaixo.map((item, idx) => (
                  <li key={idx}>{item.produto}</li>
                ))}
              </ul>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <h2 className="font-semibold">Fluxo de Caixa</h2>
          <p>Entradas: R$ {dados.caixa.entradas.toFixed(2)}</p>
          <p>Saídas: R$ {dados.caixa.saidas.toFixed(2)}</p>
          <p className="font-bold mt-2">
            Saldo: R$ {saldoCaixa.toFixed(2)} {saldoCaixa < 0 && "(negativo)"}
          </p>
        </CardContent>
      </Card>

      <Button onClick={() => alert("Futuramente: tela para atualizar dados")}>Atualizar Dados</Button>
    </div>
  );
}
